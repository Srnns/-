// pages/conflict/conflict.js
const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']

Page({
  data: {
    conflictGroups: [],
    hasConflict: false
  },

  onLoad() {
    this.analyzeConflicts()
  },

  onShow() {
    this.analyzeConflicts()
  },

  analyzeConflicts() {
    const courses = wx.getStorageSync('courses') || []
    const groups = []
    const used = new Set()

    for (let i = 0; i < courses.length; i++) {
      if (used.has(i)) continue
      const group = [courses[i]]
      for (let j = i + 1; j < courses.length; j++) {
        if (used.has(j)) continue
        const a = courses[i]
        const b = courses[j]
        if (a.dayOfWeek === b.dayOfWeek &&
            a.startSection <= b.endSection &&
            a.endSection >= b.startSection) {
          group.push(b)
          used.add(j)
        }
      }
      if (group.length > 1) {
        used.add(i)
        groups.push({
          dayName: days[group[0].dayOfWeek - 1],
          section: `第${group[0].startSection}-${group[0].endSection}节`,
          courses: group.map(c => ({
            ...c,
            dayName: days[c.dayOfWeek - 1]
          }))
        })
      }
    }

    this.setData({
      conflictGroups: groups,
      hasConflict: groups.length > 0
    })
  }
})
