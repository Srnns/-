// pages/addCourse/addCourse.js
const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57', '#ff9ff3', '#54a0ff']

Page({
  data: {
    days: days,
    dayIndex: 0,
    name: '',
    teacher: '',
    location: '',
    startSection: 1,
    endSection: 2
  },

  onDayChange(e) {
    this.setData({
      dayIndex: parseInt(e.detail.value)
    })
  },

  onNameInput(e) {
    this.setData({ name: e.detail.value })
  },

  onTeacherInput(e) {
    this.setData({ teacher: e.detail.value })
  },

  onLocationInput(e) {
    this.setData({ location: e.detail.value })
  },

  onStartChange(e) {
    const val = parseInt(e.detail.value)
    this.setData({
      startSection: val + 1,
      endSection: Math.max(val + 1, this.data.endSection)
    })
  },

  onEndChange(e) {
    const val = parseInt(e.detail.value)
    this.setData({
      endSection: val + 1
    })
  },

  validate() {
    if (!this.data.name.trim()) {
      wx.showToast({ title: '请输入课程名称', icon: 'none' })
      return false
    }
    if (this.data.startSection > this.data.endSection) {
      wx.showToast({ title: '开始节次不能大于结束节次', icon: 'none' })
      return false
    }
    return true
  },

  saveCourse() {
    if (!this.validate()) return

    const courses = wx.getStorageSync('courses') || []
    const color = colors[Math.floor(Math.random() * colors.length)]
    const newCourse = {
      id: Date.now().toString(),
      name: this.data.name.trim(),
      teacher: this.data.teacher.trim(),
      location: this.data.location.trim(),
      dayOfWeek: this.data.dayIndex + 1,
      startSection: this.data.startSection,
      endSection: this.data.endSection,
      color: color
    }

    // 检测冲突
    const conflicts = courses.filter(c =>
      c.dayOfWeek === newCourse.dayOfWeek &&
      c.startSection <= newCourse.endSection &&
      c.endSection >= newCourse.startSection
    )

    if (conflicts.length > 0) {
      wx.showModal({
        title: '课程冲突',
        content: `该时间段与 "${conflicts[0].name}" 冲突，是否仍要添加？`,
        success: (res) => {
          if (res.confirm) {
            this.doSave(newCourse)
          }
        }
      })
    } else {
      this.doSave(newCourse)
    }
  },

  doSave(course) {
    const courses = wx.getStorageSync('courses') || []
    courses.push(course)
    wx.setStorageSync('courses', courses)
    wx.showToast({ title: '添加成功', icon: 'success' })
    setTimeout(() => {
      wx.navigateBack()
    }, 800)
  }
})
