// pages/index/index.js
const app = getApp()

const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']

Page({
  data: {
    courses: [],
    hasConflict: false
  },

  onLoad() {
    this.loadCourses()
  },

  onShow() {
    this.loadCourses()
  },

  loadCourses() {
    let courses = wx.getStorageSync('courses') || []
    // 检测冲突
    const conflictSet = this.detectConflicts(courses)
    courses = courses.map(c => ({
      ...c,
      dayName: days[c.dayOfWeek - 1],
      hasConflict: conflictSet.has(c.id)
    }))
    this.setData({
      courses: courses,
      hasConflict: conflictSet.size > 0
    })
  },

  detectConflicts(courses) {
    const conflictSet = new Set()
    for (let i = 0; i < courses.length; i++) {
      for (let j = i + 1; j < courses.length; j++) {
        const a = courses[i]
        const b = courses[j]
        if (a.dayOfWeek === b.dayOfWeek &&
            a.startSection <= b.endSection &&
            a.endSection >= b.startSection) {
          conflictSet.add(a.id)
          conflictSet.add(b.id)
        }
      }
    }
    return conflictSet
  },

  goToAdd() {
    wx.navigateTo({
      url: '/pages/addCourse/addCourse'
    })
  },

  deleteCourse(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '提示',
      content: '确定删除该课程吗？',
      success: (res) => {
        if (res.confirm) {
          let courses = wx.getStorageSync('courses') || []
          courses = courses.filter(c => c.id !== id)
          wx.setStorageSync('courses', courses)
          this.loadCourses()
          wx.showToast({ title: '删除成功', icon: 'success' })
        }
      }
    })
  },

  goToConflict() {
    wx.switchTab({
      url: '/pages/conflict/conflict'
    })
  }
})
