App({
  onLaunch() {
    console.log('课程冲突检测小程序启动')
    // 从本地存储加载课程数据
    const courses = wx.getStorageSync('courses') || []
    this.globalData.courses = courses
  },
  globalData: {
    courses: []
  }
})
